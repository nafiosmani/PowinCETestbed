#!/bin/bash

mainHeader="IP, in, 1-clOff, On, 1-eHOff, On, 1-hpOff, On,  1-fnHOff, On, 1-fnLOff, On, 2-clOff, On, 2-eHOff, On, 2-hpOff, On,  2-fnHOff, On, 2-fnLOff, On"

start() {
 curl --connect-timeout 5 -s 10.0.$1.$2:8080/feather/diagnostic/start > /dev/null
}


check () {
  header=""
  cachedReport=$(curl --connect-timeout 5 -s 10.0.$1.$2:8080/feather/diagnostic/report)
  header="\n$(echo -n 10.0.$1.$2),"

  declare -a items=(
        ".results.HVAC1.InitialConditions"
        ".results.HVAC1.CoolingModeOff"
        ".results.HVAC1.CoolingModeOn"
        ".results.HVAC1.ElectricHeatModeOff"
        ".results.HVAC1.ElectricHeatModeOn"
        ".results.HVAC1.HeatPumpModeOff"
        ".results.HVAC1.HeatPumpModeOn"
        ".results.HVAC1.StackFanHighOff"
        ".results.HVAC1.StackFanHighOn"
        ".results.HVAC1.StackFanLowOff"
        ".results.HVAC1.StackFanLowOn"
        ".results.HVAC2.CoolingModeOff"
        ".results.HVAC2.CoolingModeOn"
        ".results.HVAC2.ElectricHeatModeOff"
        ".results.HVAC2.ElectricHeatModeOn"
        ".results.HVAC2.HeatPumpModeOff"
        ".results.HVAC2.HeatPumpModeOn"
        ".results.HVAC2.StackFanHighOff"
        ".results.HVAC2.StackFanHighOn"
        ".results.HVAC2.StackFanLowOff"
        ".results.HVAC2.StackFanLowOn"
    )


  for item in "${items[@]}"
    do
        header="${header} $(echo -n $cachedReport | jq -r "$item" | tr '\n' ', ' | sed 's/FAIL/\\e[1;31mFAIL\\e[0m/' | sed 's/PASS/\\e[32mPASS\\e[0m/' | sed 's/null/ /' | sed 's/INCOMPLETE/INC./'),"
    done
  echo $header
}

export -f check
export -f start

#echo -e $(echo $mainHeader) $(parallel -j22 -k check $1 {} ::: 3 {10..105..5}) | column -t -s' '
#parallel -j22 -k start $1 {} ::: 3 {10..105..5}
echo -e $(echo -e $mainHeader) $(parallel -j22 -k check $1 {} ::: 3 {10..105..5}) | column -t -s','

