#!/bin/bash

mainHeader="Stage, StartAirT, FinalAirT, StartSupplyT, FinalSupplyT, Tested_CT, Other_CT, \n"

end="ENDCOLOR"
fail="FAILCOLOR"
pass="\e[1;32m"

check () {
  header=""
  cachedReport=$(curl --connect-timeout 5 -s $1:8080/feather/diagnostic/collect)

  declare -a items=(
        "initialSpaceAirTemperature"
        "finalSpaceAirTemperature"
        "initialSupplyAirTemperature"
        "finalSupplyAirTemperature"
        "testUnitCurrent"
        "standbyUnitCurrent"
    )

  declare -a tests=(
        "StackFanLowOnTest"
        "StackFanLowOffTest"
        "CoolingModeOnTest"
        "CoolingModeOffTest"
        "ElectricHeatingModeOnTest"
        "ElectricHeatingModeOffTest"
        "HeatPumpModeOnTest"
        "HeatPumpModeOffTest"
      )
  declare -a hvacs=(
        "hvac1"
        "hvac2"
      )

  for hvac in "${hvacs[@]}"; do
    for test in "${tests[@]}"; do
          header="${header}${hvac} $(echo -n ${test} | sed 's&Test&&' | sed 's&Stack&&'), "
      for item in "${items[@]}"; do
        if echo $item | grep -i testUnitCurrent > /dev/null; then
          result=$(colorRange $(echo -n $cachedReport | jq -r ".${hvac}${test}.${item}") $(echo -n $cachedReport | jq -r ".${hvac}${test}.testUnitCurrentRange.low") $(echo -n $cachedReport | jq -r ".${hvac}${test}.testUnitCurrentRange.high"))
          header="${header} $(echo -n $result | tr '\n' ', ' | sed 's&null&&' ),"
        elif echo $item | grep -i standbyUnitCurrent > /dev/null; then
          result=$(colorRange $(echo -n $cachedReport | jq -r ".${hvac}${test}.${item}") $(echo -n $cachedReport | jq -r ".${hvac}${test}.standbyUnitCurrentRange.low") $(echo -n $cachedReport | jq -r ".${hvac}${test}.standbyUnitCurrentRange.high"))
          header="${header} $(echo -n $result | tr '\n' ', ' | sed 's&null&&' ),"
        else
          header="${header} $(echo -n $cachedReport | jq -r ".${hvac}${test}.${item}" | xargs -I {} -E null printf %3.1f {} | tr '\n' ', ' | sed 's&null&&' ),"
        fi
      done
	header="${header}\n"
    done
  done
  echo $header
}

colorRange () {
  ret=""
  input=$1
  lowRange=$(echo $2 | sed 's&Infinity&100&')
  highRange=$(echo $3 | sed 's&Infinity&100&')
  if python -c "exit(0 if $input > ${highRange} else 1)"; then
    ret=$fail
  elif python -c "exit(0 if $input < ${lowRange} else 1)"; then
    ret=$fail
  else
    ret=""
  fi
  printf "$ret%3.1f$end\n" $input
}

echo -e $(echo -e $mainHeader) \\n$(check $1 | sed 's^FAILCOLOR^\\e[1;31m^g' | sed 's^ENDCOLOR^\\e[0m^g' ) | column -t -s','


