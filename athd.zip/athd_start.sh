#!/bin/bash


start() {
 curl --connect-timeout 5 -s 10.0.$1.$2:8080/feather/diagnostic/start > /dev/null
}



export -f start

parallel -j22 -k start $1 {} ::: 3 {10..105..5}

